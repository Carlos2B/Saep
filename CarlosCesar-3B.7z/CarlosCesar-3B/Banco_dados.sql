create table usuario(
 id_  serial primary key not null,
 nome varchar(50) not null,
 email varchar(50) not null
);

CREATE TYPE prioridade_type AS ENUM ('baixa', 'media', 'alta');

CREATE TYPE status_type AS ENUM ('a fazer', 'fazendo', 'pronto');

create table tarefa(
	id_tarefa serial primary key not null,
	descricao varchar(50) not null,
	setor varchar(50) not null,
	prioridade varchar(50) not null,
	data_cadastro varchar(10) not null,
	status status_type NOT NULL DEFAULT 'a fazer',
	id_usuario varchar(50) not null,
	foreign key (id_usuario) references usuario(id_)
);

select * from public.usuario